-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `httptest`
--

DROP TABLE IF EXISTS `httptest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `httptest` (
  `httptestid` bigint(20) unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `applicationid` bigint(20) unsigned DEFAULT NULL,
  `nextcheck` int(11) NOT NULL DEFAULT '0',
  `delay` int(11) NOT NULL DEFAULT '60',
  `status` int(11) NOT NULL DEFAULT '0',
  `variables` text NOT NULL,
  `agent` varchar(255) NOT NULL DEFAULT 'Zabbix',
  `authentication` int(11) NOT NULL DEFAULT '0',
  `http_user` varchar(64) NOT NULL DEFAULT '',
  `http_password` varchar(64) NOT NULL DEFAULT '',
  `hostid` bigint(20) unsigned NOT NULL,
  `templateid` bigint(20) unsigned DEFAULT NULL,
  `http_proxy` varchar(255) NOT NULL DEFAULT '',
  `retries` int(11) NOT NULL DEFAULT '1',
  `ssl_cert_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_password` varchar(64) NOT NULL DEFAULT '',
  `verify_peer` int(11) NOT NULL DEFAULT '0',
  `verify_host` int(11) NOT NULL DEFAULT '0',
  `headers` text NOT NULL,
  PRIMARY KEY (`httptestid`),
  UNIQUE KEY `httptest_2` (`hostid`,`name`),
  KEY `httptest_1` (`applicationid`),
  KEY `httptest_3` (`status`),
  KEY `httptest_4` (`templateid`),
  CONSTRAINT `c_httptest_1` FOREIGN KEY (`applicationid`) REFERENCES `applications` (`applicationid`),
  CONSTRAINT `c_httptest_2` FOREIGN KEY (`hostid`) REFERENCES `hosts` (`hostid`) ON DELETE CASCADE,
  CONSTRAINT `c_httptest_3` FOREIGN KEY (`templateid`) REFERENCES `httptest` (`httptestid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httptest`
--

LOCK TABLES `httptest` WRITE;
/*!40000 ALTER TABLE `httptest` DISABLE KEYS */;
INSERT INTO `httptest` VALUES (3,'login',1200,1467464415,60,1,'','Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0)',0,'','',10259,NULL,'',1,'','','',0,0,''),(4,'www.droibaas.com',797,1523898065,60,0,'','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.36 OPR/25.0.1614.50',0,'','',10084,NULL,'',1,'','','',0,0,''),(5,'http://www.droibaas.com/Index/about.html',2116,1523898081,60,0,'','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36',0,'','',10311,NULL,'',1,'','','',0,0,''),(6,'bbs.droibaas.com',2116,1523898041,60,0,'','Zabbix',0,'','',10311,NULL,'',1,'','','',0,0,''),(7,'job.droibaas.com',2116,1482491037,60,1,'','Zabbix',0,'','',10311,NULL,'',1,'','','',0,0,''),(8,'BaaSWeb',2336,1523898055,60,0,'','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36',0,'','',10333,NULL,'',1,'','','',0,0,''),(9,'10.10.60.8:20550/version/cluster',893,1523898138,600,0,'','Zabbix',0,'','',10206,NULL,'',1,'','','',0,0,''),(12,'PushSevice',2197,1523898047,60,0,'','Zabbix',0,'','',10321,NULL,'',1,'','','',0,0,''),(13,'Push',2828,1523898055,60,0,'','Zabbix',0,'','',10325,NULL,'http://10.10.50.2:8080',1,'','','',0,0,''),(14,'FileStorage',2828,1523898125,120,0,'','Zabbix',0,'','',10325,NULL,'http://10.10.50.2:8080',1,'','','',0,0,''),(16,'Account',2828,1523898041,60,0,'','Zabbix',0,'','',10325,NULL,'http://10.10.50.2:8080',1,'','','',0,0,''),(17,'Update',2828,1523898070,60,0,'','Zabbix',0,'','',10325,NULL,'',1,'','','',0,0,''),(18,'Feedback',2828,1523898055,60,0,'','Zabbix',0,'','',10325,NULL,'',1,'','','',0,0,''),(19,'Analytics',2828,1523898066,60,0,'','Zabbix',0,'','',10325,NULL,'',1,'','','',0,0,''),(20,'Web',2828,1523898081,60,0,'','Zabbix',0,'','',10325,NULL,'http://10.10.50.2:8080',1,'','','',0,0,''),(21,'DataStorage',2828,1523898041,60,0,'','Zabbix',0,'','',10325,NULL,'',1,'','','',0,0,''),(22,'CloudEngine',2828,1523898095,60,0,'','Zabbix',0,'','',10325,NULL,'',1,'','','',0,0,''),(23,'CloudLog',2828,1523898073,60,0,'','Zabbix',0,'','',10325,NULL,'',1,'','','',0,0,''),(24,'CDN Vendors',2247,1523898275,300,0,'','Zabbix',0,'','',10325,NULL,'http://10.10.50.2:8080',1,'','','',0,0,''),(25,'Account',351,1523898081,60,0,'','Zabbix',0,'','',10084,NULL,'',1,'','','',0,0,''),(26,'海外帐号服务',2851,1523898086,60,0,'','Zabbix',0,'','',10384,NULL,'',1,'','','',0,0,''),(28,'BaaS帐号',2851,1523898073,60,0,'','Zabbix',0,'','',10384,NULL,'',1,'','','',0,0,''),(31,'newsstream',3237,1523898106,120,0,'','Zabbix',0,'','',10426,NULL,'',1,'','','',0,0,'');
/*!40000 ALTER TABLE `httptest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-17  1:00:36
