-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `userid` bigint(20) unsigned NOT NULL,
  `alias` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `surname` varchar(100) NOT NULL DEFAULT '',
  `passwd` char(32) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `autologin` int(11) NOT NULL DEFAULT '0',
  `autologout` int(11) NOT NULL DEFAULT '900',
  `lang` varchar(5) NOT NULL DEFAULT 'en_GB',
  `refresh` int(11) NOT NULL DEFAULT '30',
  `type` int(11) NOT NULL DEFAULT '1',
  `theme` varchar(128) NOT NULL DEFAULT 'default',
  `attempt_failed` int(11) NOT NULL DEFAULT '0',
  `attempt_ip` varchar(39) NOT NULL DEFAULT '',
  `attempt_clock` int(11) NOT NULL DEFAULT '0',
  `rows_per_page` int(11) NOT NULL DEFAULT '50',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `users_1` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','Zabbix','Administrator','555c22851b22d543dbef7207e082cce7','',1,0,'en_US',30,3,'default',0,'192.168.3.39',1491805604,50),(2,'guest','','','d41d8cd98f00b204e9800998ecf8427e','',1,0,'en_GB',30,1,'default',0,'',0,50),(8,'database','database','database','3d5f0c4e74e676297bb2a4781f67959b','',1,0,'en_US',30,1,'default',0,'',0,50),(14,'liwei','liwei','liwei','1c181c049eb10a1edceded419eaf04af','',1,0,'en_GB',30,1,'default',0,'192.168.3.61',1492157538,50),(15,'masongyu','masongyu','masongyu','d3cc413524c3dee0190b69ae51675f5d','',1,0,'en_GB',30,1,'default',0,'',0,50),(18,'log','log','','32f3d0330e0326b6b5afb0eb8bcd6dac','',1,0,'en_GB',30,2,'default',0,'',0,50),(19,'tony','tony','hsu','477977b45d8d765d72432dd9b7473a4f','',1,0,'en_GB',30,2,'default',0,'10.128.116.76',1478590607,50),(20,'manager','manager','manager','ab40e72148196c42fa75dc03fc96b60c','',1,0,'en_GB',30,1,'default',0,'',0,50),(22,'dongjunhan','dongjunhan','dongjunhan','ba3beca81333385574693fc1e2440621','',1,0,'en_GB',30,2,'default',3,'10.128.80.77',1478136439,50),(23,'ruanheming','ruanheming','ruanheming','1c6e27d475851ade3528968b3f948cb3','',0,0,'en_GB',30,1,'default',0,'',0,50),(24,'xudeping','xudeping','xudeping','2504d1e9dd885adb32be6ab75eac1102','',1,0,'en_GB',30,1,'default',0,'10.128.81.60',1478570318,50),(25,'chenyifan','chenyifan','chenyifan','5d45e122e224eb32ce3c5c266f2ddc1f','',0,0,'en_GB',30,1,'default',0,'',0,50),(26,'zengjianxun','zengjianxun','zengjianxun','e5c9f92d86633bfc9a7b45c1d1553167','',0,0,'en_GB',30,1,'default',0,'',0,50),(27,'yehongjun','yehongjun','yehongjun','477886495f0fcd420ee4445c43157d61','',0,0,'en_GB',30,1,'default',0,'',0,50),(28,'limengxiu','limengxiu','limengxiu','ca54b65ec553d7defdedff9c0dced54a','',0,0,'en_GB',30,1,'default',0,'',0,50),(29,'hongminghong','hongminghong','hongminghong','d3835f2bdc7e9d387ca399f692d2ca59','',1,0,'en_GB',30,1,'default',0,'10.128.116.188',1473666678,50),(30,'linzhaowei','linzhaowei','linzhaowei','398a0639a760dd3c17a5f5142921ad37','',0,0,'en_GB',30,1,'default',4,'10.128.116.76',1474853877,50),(31,'caizongcheng','caizongcheng','caizongcheng','8ff1d97c13a2d68d1c6dce2c2124141f','',0,0,'en_GB',30,1,'default',0,'',0,50),(32,'adam.chen','Adam','Chen','e61fd4979b3ebf06b9d5e33d8633f3a4','',1,0,'en_US',30,2,'default',0,'',0,50),(33,'neil','Neil','','c0aa5a4e298a327a3c0a9bb848637ed9','',1,0,'en_GB',30,1,'default',0,'',0,50),(34,'james','james','','1c63129ae9db9c60c3e8aa94d3e00495','',1,0,'en_US',30,1,'default',0,'10.128.116.188',1473651090,50),(35,'taipei_monitor','taipei_monitor','','4144c946008660206f38b4da5540e73e','',1,0,'en_GB',30,1,'default',0,'',0,50),(36,'huanghua','huanghua','huanghua','5fce1b3e34b520afeffb37ce08c7cd66','',0,0,'en_GB',30,1,'default',0,'',0,50),(37,'taipeiguanli','taipeiguanli','taipeiguanli','5fce1b3e34b520afeffb37ce08c7cd66','',0,0,'en_GB',30,1,'default',0,'',0,50),(38,'miaowenzhi','miaowenzhi','miaowenzhi','5fce1b3e34b520afeffb37ce08c7cd66','',1,0,'en_GB',30,1,'default',0,'',0,50),(39,'zhangyu','zhangyu','zhangyu','5fce1b3e34b520afeffb37ce08c7cd66','',1,0,'en_GB',30,1,'default',0,'192.168.3.90',1484731654,50),(40,'sumoyu','sumoyu','sumoyu','5fce1b3e34b520afeffb37ce08c7cd66','',0,0,'en_GB',30,1,'default',0,'',0,50),(41,'zhaojia','zhaojia','zhaojia','5fce1b3e34b520afeffb37ce08c7cd66','',1,0,'en_GB',30,1,'default',0,'192.168.3.95',1487643669,50),(42,'daiguoyu','daiguoyu','daiguoyu','5fce1b3e34b520afeffb37ce08c7cd66','',0,0,'en_GB',30,1,'default',0,'',0,50),(43,'daiguoxi','daiguoxi','daiguoxi','5fce1b3e34b520afeffb37ce08c7cd66','',1,0,'en_GB',30,1,'default',0,'10.128.116.113',1490760852,50),(45,'liuyongyue','liuyongyue','liuyongyue','5fce1b3e34b520afeffb37ce08c7cd66','',1,0,'en_GB',30,1,'default',0,'192.168.3.141',1490853082,50),(46,'monitor','monitor','monitor','5fce1b3e34b520afeffb37ce08c7cd66','',1,0,'en_GB',30,1,'default',0,'',0,50);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-03  1:01:42
