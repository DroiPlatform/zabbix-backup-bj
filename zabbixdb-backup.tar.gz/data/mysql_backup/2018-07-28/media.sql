-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `mediaid` bigint(20) unsigned NOT NULL,
  `userid` bigint(20) unsigned NOT NULL,
  `mediatypeid` bigint(20) unsigned NOT NULL,
  `sendto` varchar(100) NOT NULL DEFAULT '',
  `active` int(11) NOT NULL DEFAULT '0',
  `severity` int(11) NOT NULL DEFAULT '63',
  `period` varchar(100) NOT NULL DEFAULT '1-7,00:00-24:00',
  PRIMARY KEY (`mediaid`),
  KEY `media_1` (`userid`),
  KEY `media_2` (`mediatypeid`),
  CONSTRAINT `c_media_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE CASCADE,
  CONSTRAINT `c_media_2` FOREIGN KEY (`mediatypeid`) REFERENCES `media_type` (`mediatypeid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (16,14,5,'5311,809f7f40cdd3b7afa5e5ef0a1f2c1842',0,60,'1-7,00:00-24:00'),(24,19,5,'5436,360113299eea067bc340bb4a31e86a9f',1,60,'1-7,00:00-24:00'),(25,19,28,'helen.chang@droi.com',0,60,'1-7,00:00-24:00'),(36,22,28,'assert.tung@droi.com',0,60,'1-7,00:00-24:00'),(37,23,28,'tannhauser.ruan@droi.com',0,60,'1-7,00:00-24:00'),(38,24,28,'tony.hsu@droi.com',0,60,'1-7,00:00-24:00'),(39,25,28,'evan.chen@droi.com',0,60,'1-7,00:00-24:00'),(40,26,28,'james.tzeng@droi.com',0,60,'1-7,00:00-24:00'),(41,27,28,'anibal.yeh@droi.com',0,60,'1-7,00:00-24:00'),(42,28,28,'george.lee@droi.com',0,60,'1-7,00:00-24:00'),(43,29,28,'james.hung@droi.com',0,60,'1-7,00:00-24:00'),(44,30,28,'steven.lin@droi.com',0,60,'1-7,00:00-24:00'),(45,31,28,'tom.tsai@droi.com',0,60,'1-7,00:00-24:00'),(61,20,28,'yangxudong@droi.com',0,60,'1-7,00:00-24:00'),(63,14,28,'wangzhongneng@droi.com',0,60,'1-7,00:00-24:00'),(66,36,28,'huanghua@droi.com',0,60,'1-7,00:00-24:00'),(72,38,28,'miaowenzhi@droi.com',0,60,'1-7,00:00-24:00'),(74,1,28,'helen.chang@droi.com',0,60,'1-7,00:00-24:00'),(76,39,28,'zhangyu@droi.com',0,60,'1-7,00:00-24:00'),(77,40,28,'sumoyu@droi.com',0,60,'1-7,00:00-24:00'),(85,1,5,'9525,af5a3e9d82d16f507eb8fdfe366e1b4c',0,60,'1-7,00:00-24:00'),(87,1,34,'droi2016',0,60,'1-7,00:00-24:00'),(89,1,34,'taipei',0,60,'1-7,00:00-24:00'),(92,37,28,'vincent.chan@droi.com',0,60,'1-7,00:00-24:00'),(93,37,28,'zhousimin@droi.com',0,60,'1-7,00:00-24:00'),(94,37,34,'SMZhouSimon',0,60,'1-7,00:00-24:00'),(95,37,34,'Vincentmagician',0,60,'1-7,00:00-24:00'),(98,20,34,'yangxudong',0,60,'1-7,00:00-24:00'),(99,22,34,'dongjunhan',0,60,'1-7,00:00-24:00'),(100,26,34,'zengjianxun',0,60,'1-7,00:00-24:00'),(101,28,34,'eaglerayp',0,60,'1-7,00:00-24:00'),(102,28,34,'limengxiu',0,60,'1-7,00:00-24:00'),(103,25,34,'chenyifan',0,60,'1-7,00:00-24:00'),(104,27,34,'yehongjun',0,60,'1-7,00:00-24:00'),(105,23,34,'ruanheming',0,60,'1-7,00:00-24:00'),(106,24,34,'xudeping',0,60,'1-7,00:00-24:00'),(107,14,34,'xiayanxue',0,60,'1-7,00:00-24:00'),(109,29,34,'hongminghong',0,60,'1-7,00:00-24:00'),(111,40,34,'fiathux',0,60,'1-7,00:00-24:00'),(112,42,34,'skyertw',0,60,'1-7,00:00-24:00'),(114,39,34,'984513956',0,60,'1-7,00:00-24:00'),(115,38,34,'miaowenzhi',0,60,'1-7,00:00-24:00'),(116,30,34,'linzhaowei',0,60,'1-7,00:00-24:00'),(117,36,34,'huanghua',0,60,'1-7,00:00-24:00'),(119,48,28,'liuyongyue@droi.com',0,60,'1-7,00:00-24:00'),(120,48,34,'wo142857',0,60,'1-7,00:00-24:00'),(121,20,28,'yuanyuan@droi.com',0,60,'1-7,00:00-24:00'),(122,20,34,'happy_fat_man',0,60,'1-7,00:00-24:00'),(124,15,28,'james.tzeng@droi.com',0,60,'1-7,00:00-24:00'),(125,15,28,'luanzhe@droi.com',0,60,'1-7,00:00-24:00'),(126,15,34,'zengjianxun',0,60,'1-7,00:00-24:00'),(128,1,34,'BaoPanPan',0,60,'1-7,00:00-24:00'),(129,43,34,'AlanZheng999',0,60,'1-7,00:00-24:00'),(130,43,34,'wxid_ws0m4zykgrdb12',0,60,'1-7,00:00-24:00'),(131,1,28,'liangshanzhen@droi.com',0,60,'1-7,00:00-24:00'),(132,1,28,'xialingfeng@droi.com',0,60,'1-7,00:00-24:00'),(133,1,34,'WuLiangFei',0,60,'1-7,00:00-24:00');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-28  1:00:57
