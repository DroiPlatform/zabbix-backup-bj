-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `mediaid` bigint(20) unsigned NOT NULL,
  `userid` bigint(20) unsigned NOT NULL,
  `mediatypeid` bigint(20) unsigned NOT NULL,
  `sendto` varchar(100) NOT NULL DEFAULT '',
  `active` int(11) NOT NULL DEFAULT '0',
  `severity` int(11) NOT NULL DEFAULT '63',
  `period` varchar(100) NOT NULL DEFAULT '1-7,00:00-24:00',
  PRIMARY KEY (`mediaid`),
  KEY `media_1` (`userid`),
  KEY `media_2` (`mediatypeid`),
  CONSTRAINT `c_media_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE CASCADE,
  CONSTRAINT `c_media_2` FOREIGN KEY (`mediatypeid`) REFERENCES `media_type` (`mediatypeid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (10,1,28,'lankemin@droi.com',0,60,'1-7,00:00-24:00'),(14,15,5,'5306,f10d8d056bebcaca41026e608d7bfe05',1,60,'1-7,00:00-24:00'),(16,14,5,'5311,809f7f40cdd3b7afa5e5ef0a1f2c1842',0,60,'1-7,00:00-24:00'),(19,15,28,'masongyu@droi.com',0,60,'1-7,00:00-24:00'),(20,15,9,'masongyu',0,60,'1-7,00:00-24:00'),(21,14,10,'mengliran',0,60,'1-7,00:00-24:00'),(23,1,8,'xitong',0,60,'1-7,00:00-24:00'),(24,19,5,'5436,360113299eea067bc340bb4a31e86a9f',1,60,'1-7,00:00-24:00'),(25,19,28,'helen.chang@droi.com',0,60,'1-7,00:00-24:00'),(30,1,11,'taipei',0,60,'1-7,00:00-24:00'),(36,22,28,'assert.tung@droi.com',0,60,'1-7,00:00-24:00'),(37,23,28,'tannhauser.ruan@droi.com',0,60,'1-7,00:00-24:00'),(38,24,28,'tony.hsu@droi.com',0,60,'1-7,00:00-24:00'),(39,25,28,'evan.chen@droi.com',0,60,'1-7,00:00-24:00'),(40,26,28,'james.tzeng@droi.com',0,60,'1-7,00:00-24:00'),(41,27,28,'anibal.yeh@droi.com',0,60,'1-7,00:00-24:00'),(42,28,28,'george.lee@droi.com',0,60,'1-7,00:00-24:00'),(43,29,28,'james.hung@droi.com',0,60,'1-7,00:00-24:00'),(44,30,28,'steven.lin@droi.com',0,60,'1-7,00:00-24:00'),(45,31,28,'tom.tsai@droi.com',0,60,'1-7,00:00-24:00'),(46,22,14,'dongjunhan',0,60,'1-7,00:00-24:00'),(47,23,15,'ruanheming',0,60,'1-7,00:00-24:00'),(48,29,21,'hongminghong',0,60,'1-7,00:00-24:00'),(49,30,22,'linzhaowei',0,60,'1-7,00:00-24:00'),(50,31,23,'caizongcheng',0,60,'1-7,00:00-24:00'),(51,28,20,'limengxiu',0,60,'1-7,00:00-24:00'),(52,27,19,'yehongjun',0,60,'1-7,00:00-24:00'),(53,24,16,'xudeping',0,60,'1-7,00:00-24:00'),(54,25,17,'chenyifan.sh',0,60,'1-7,00:00-24:00'),(55,26,18,'zengjianxun',0,60,'1-7,00:00-24:00'),(60,20,28,'renshulin@droi.com',0,60,'1-7,00:00-24:00'),(61,20,28,'yangxudong@droi.com',0,60,'1-7,00:00-24:00'),(62,20,12,'guanli',0,60,'1-7,00:00-24:00'),(63,14,28,'wangzhongneng@droi.com',0,60,'1-7,00:00-24:00'),(66,36,28,'huanghua@droi.com',0,60,'1-7,00:00-24:00'),(67,36,24,'huanghua',0,60,'1-7,00:00-24:00'),(68,37,25,'taipeiguanli',0,60,'1-7,00:00-24:00'),(70,38,26,'miaowenzhi',0,60,'1-7,00:00-24:00'),(71,39,27,'zhangyu',0,60,'1-7,00:00-24:00'),(72,38,28,'miaowenzhi@droi.com',0,60,'1-7,00:00-24:00'),(74,1,28,'helen.chang@droi.com',0,60,'1-7,00:00-24:00'),(75,1,28,'zhoujun@droi.com',0,63,'1-7,00:00-24:00'),(76,39,28,'zhangyu@droi.com',0,60,'1-7,00:00-24:00'),(77,40,28,'sumoyu@droi.com',0,60,'1-7,00:00-24:00'),(78,40,29,'sumoyu',0,60,'1-7,00:00-24:00'),(79,41,28,'zhaojia@droi.com',0,60,'1-7,00:00-24:00'),(80,41,30,'zhaojia',0,60,'1-7,00:00-24:00'),(81,42,31,'daiguoyu',0,60,'1-7,00:00-24:00'),(82,45,28,'liuyongyue@droi.com',0,60,'1-7,00:00-24:00'),(83,39,33,'zhangyu2.sh',0,60,'1-7,00:00-24:00'),(84,45,32,'liuyongyue.sh',0,60,'1-7,00:00-24:00');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-27  1:00:56
