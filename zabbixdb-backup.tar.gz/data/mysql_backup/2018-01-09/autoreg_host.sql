-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autoreg_host`
--

DROP TABLE IF EXISTS `autoreg_host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autoreg_host` (
  `autoreg_hostid` bigint(20) unsigned NOT NULL,
  `proxy_hostid` bigint(20) unsigned DEFAULT NULL,
  `host` varchar(64) NOT NULL DEFAULT '',
  `listen_ip` varchar(39) NOT NULL DEFAULT '',
  `listen_port` int(11) NOT NULL DEFAULT '0',
  `listen_dns` varchar(64) NOT NULL DEFAULT '',
  `host_metadata` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`autoreg_hostid`),
  KEY `autoreg_host_1` (`proxy_hostid`,`host`),
  CONSTRAINT `c_autoreg_host_1` FOREIGN KEY (`proxy_hostid`) REFERENCES `hosts` (`hostid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autoreg_host`
--

LOCK TABLES `autoreg_host` WRITE;
/*!40000 ALTER TABLE `autoreg_host` DISABLE KEYS */;
INSERT INTO `autoreg_host` VALUES (1,NULL,'datanode01','10.10.60.1',10050,'localhost',''),(2,NULL,'datanode02','10.10.60.2',10050,'localhost',''),(3,NULL,'datanode03','10.10.60.3',10050,'bogon',''),(4,NULL,'datanode04','10.10.60.4',10050,'localhost',''),(5,NULL,'datanode05','10.10.60.5',10050,'localhost',''),(6,NULL,'datanode06','10.10.60.6',10050,'localhost',''),(7,NULL,'datanode07','10.10.60.7',10050,'localhost',''),(8,NULL,'datanode08','10.10.60.8',10050,'localhost',''),(9,NULL,'datanode09','10.10.60.9',10050,'localhost',''),(10,NULL,'worker-3','10.10.50.62',10050,'','coreos'),(11,NULL,'master','10.10.50.78',10050,'','coreos'),(12,NULL,'worker-1','10.10.50.60',10050,'','coreos'),(13,NULL,'worker-2','10.10.50.61',10050,'','coreos'),(14,NULL,'gogs','10.10.50.13',10050,'',''),(15,NULL,'webcli','10.10.40.215',10050,'',''),(16,NULL,'worker-4','10.10.50.56',10050,'','coreos'),(17,NULL,'worker-5','10.10.50.53',10050,'','coreos'),(18,NULL,'worker-6','10.10.50.54',10050,'','coreos'),(19,NULL,'worker-7','10.10.50.55',10050,'','coreos'),(20,NULL,'k8s-jump','10.10.50.11',10050,'',''),(21,NULL,'e2e-monitor-agent','10.10.50.12',10050,'',''),(22,NULL,'10.10.40.27','10.10.47.25',10050,'',''),(23,NULL,'10.10.40.10','10.10.40.10',10050,'',''),(24,NULL,'10.10.60.10','10.10.60.10',10050,'',''),(25,NULL,'10.10.60.11','10.10.60.11',10050,'',''),(26,NULL,'10.10.40.80','10.10.50.30',10050,'',''),(27,NULL,'10.10.40.25','10.10.50.95',10050,'',''),(28,NULL,'10.10.40.26','10.10.50.96',10050,'',''),(29,NULL,'10.10.50.96','10.10.50.96',10050,'',''),(30,NULL,'10.10.70.11','10.10.70.11',10050,'',''),(31,NULL,'10.10.70.1','10.10.70.1',10050,'',''),(32,NULL,'10.10.70.2','10.10.70.2',10050,'',''),(33,NULL,'10.10.70.3','10.10.70.3',10050,'',''),(34,NULL,'10.10.70.4','10.10.70.4',10050,'',''),(35,NULL,'10.10.70.5','10.10.70.5',10050,'',''),(36,NULL,'10.10.70.6','10.10.70.6',10050,'',''),(37,NULL,'10.10.70.7','10.10.70.7',10050,'',''),(38,NULL,'10.10.70.9','10.10.70.9',10050,'',''),(39,NULL,'10.10.70.10','10.10.70.10',10050,'',''),(40,NULL,'10.10.70.12','10.10.70.12',10050,'',''),(41,NULL,'10.10.40.50','10.10.50.80',10050,'',''),(42,NULL,'10.10.50.30','10.10.50.30',10050,'',''),(43,NULL,'10.10.50.80','10.10.50.80',10050,'',''),(44,NULL,'10.10.50.31','10.10.50.31',10050,'',''),(45,NULL,'10.10.40.226','10.10.40.226',10050,'',''),(46,NULL,'10.10.40.61','10.10.47.61',10050,'',''),(47,NULL,'10.10.40.62','10.10.40.62',10050,'',''),(48,NULL,'10.10.40.63','10.10.40.63',10050,'',''),(49,NULL,'10.10.80.1','10.10.80.1',10050,'',''),(50,NULL,'10.10.80.2','10.10.80.2',10050,'',''),(51,NULL,'10.10.80.3','10.10.80.3',10050,'',''),(52,NULL,'10.10.80.4','10.10.80.4',10050,'',''),(53,NULL,'10.10.80.5','10.10.80.5',10050,'',''),(54,NULL,'10.10.80.6','10.10.80.6',10050,'',''),(55,NULL,'10.10.80.7','10.10.80.7',10050,'',''),(56,NULL,'10.10.80.8','10.10.80.8',10050,'',''),(57,NULL,'10.10.80.9','10.10.80.9',10050,'',''),(58,NULL,'10.10.80.246','10.10.80.246',10050,'',''),(59,NULL,'10.10.80.226','10.10.80.226',10050,'',''),(60,NULL,'10.10.80.215','10.10.80.215',10050,'',''),(61,NULL,'baas-web','10.10.47.24',10050,'',''),(62,NULL,'10.10.80.238','10.10.80.238',10050,'',''),(63,NULL,'10.10.80.80','10.10.80.80',10050,'',''),(64,NULL,'10.10.80.241','10.10.80.241',10050,'',''),(65,NULL,'zabbix_server_detect.nasl-1495767483','192.168.2.195',10050,'',''),(66,NULL,'zabbix_server_detect.nasl-1495767544','192.168.2.121',10050,'',''),(67,NULL,'zabbix_server_detect.nasl-1495770306','192.168.2.121',10050,'',''),(68,NULL,'zabbix_server_detect.nasl-1495778961','192.168.2.195',10050,'',''),(69,NULL,'kafka-7','10.10.50.97',10050,'',''),(70,NULL,'10.10.80.156','10.10.80.156',10050,'',''),(71,NULL,'10.10.80.232','10.10.80.232',10050,'',''),(72,NULL,'10.10.80.221','10.10.80.221',10050,'',''),(73,NULL,'10.10.80.240','10.10.80.240',10050,'',''),(74,NULL,'10.10.80.162','10.10.80.162',10050,'',''),(75,NULL,'10.10.80.248','10.10.80.248',10050,'',''),(76,NULL,'nfs-ha-1','10.10.46.12',10050,'',''),(77,NULL,'mongo-datanode-M2','10.10.50.93',10050,'',''),(78,NULL,'mongo-datanode-M1','10.10.50.91',10050,'',''),(79,NULL,'data-aggregate-1','10.10.50.98',10050,'',''),(80,NULL,'10.10.80.250','10.10.80.250',10050,'',''),(81,NULL,'10.10.80.223','10.10.80.223',10050,'',''),(82,NULL,'10.10.80.244','10.10.80.244',10050,'',''),(83,NULL,'10.10.80.218','10.10.80.218',10050,'',''),(84,NULL,'10.10.80.224','10.10.80.224',10050,'',''),(85,NULL,'10.10.80.201','10.10.80.201',10050,'',''),(86,NULL,'10.10.80.164','10.10.80.164',10050,'',''),(87,NULL,'10.10.50.252','10.10.80.252',10050,'',''),(88,NULL,'10.10.80.194','10.10.80.194',10050,'',''),(89,NULL,'10.10.80.202','10.20.40.253',10050,'',''),(90,NULL,'10.10.50.92','10.10.50.92',10050,'',''),(91,NULL,'10.10.80.163','10.10.80.163',10050,'',''),(92,NULL,'10.10.80.69','10.10.80.69',10050,'',''),(93,NULL,'10.10.80.217','10.10.80.217',10050,'',''),(94,NULL,'10.10.80.235','10.10.80.235',10050,'',''),(95,NULL,'10.10.80.115','10.10.80.115',10050,'','');
/*!40000 ALTER TABLE `autoreg_host` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-09  1:00:07
