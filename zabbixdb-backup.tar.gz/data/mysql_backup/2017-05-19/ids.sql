-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ids`
--

DROP TABLE IF EXISTS `ids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ids` (
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `field_name` varchar(64) NOT NULL DEFAULT '',
  `nextid` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`table_name`,`field_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ids`
--

LOCK TABLES `ids` WRITE;
/*!40000 ALTER TABLE `ids` DISABLE KEYS */;
INSERT INTO `ids` VALUES ('acknowledges','acknowledgeid',666),('actions','actionid',31),('applications','applicationid',2879),('application_template','application_templateid',2847),('auditlog','auditid',22652),('auditlog_details','auditdetailid',8918),('conditions','conditionid',108),('dchecks','dcheckid',9),('drules','druleid',9),('functions','functionid',28348),('graphs','graphid',42327),('graphs_items','gitemid',96389),('groups','groupid',33),('group_prototype','group_prototypeid',11),('hostmacro','hostmacroid',27),('hosts','hostid',10386),('hosts_groups','hostgroupid',465),('hosts_templates','hosttemplateid',902),('housekeeper','housekeeperid',541618),('httpstep','httpstepid',61),('httpstepitem','httpstepitemid',183),('httptest','httptestid',30),('httptestitem','httptestitemid',90),('images','imageid',192),('interface','interfaceid',361),('items','itemid',131901),('items_applications','itemappid',131687),('item_condition','item_conditionid',389),('item_discovery','itemdiscoveryid',95738),('maintenances','maintenanceid',207),('maintenances_groups','maintenance_groupid',325),('maintenances_hosts','maintenance_hostid',529),('maintenances_windows','maintenance_timeperiodid',246),('mappings','mappingid',171),('media','mediaid',84),('media_type','mediatypeid',33),('opcommand_hst','opcommand_hstid',4),('operations','operationid',57),('opmessage_grp','opmessage_grpid',7),('opmessage_usr','opmessage_usrid',72),('profiles','profileid',11773),('rights','rightid',222),('screens','screenid',154),('screens_items','screenitemid',3351),('screen_user','screenuserid',330),('screen_usrgrp','screenusrgrpid',275),('sysmaps','sysmapid',4),('sysmaps_elements','selementid',67),('sysmaps_links','linkid',342),('timeperiods','timeperiodid',246),('triggers','triggerid',25514),('trigger_depends','triggerdepid',1268),('users','userid',46),('users_groups','id',61),('usrgrp','usrgrpid',23),('valuemaps','valuemapid',18);
/*!40000 ALTER TABLE `ids` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-19  1:00:40
