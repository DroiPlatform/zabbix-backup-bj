-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ids`
--

DROP TABLE IF EXISTS `ids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ids` (
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `field_name` varchar(64) NOT NULL DEFAULT '',
  `nextid` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`table_name`,`field_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ids`
--

LOCK TABLES `ids` WRITE;
/*!40000 ALTER TABLE `ids` DISABLE KEYS */;
INSERT INTO `ids` VALUES ('acknowledges','acknowledgeid',666),('actions','actionid',31),('applications','applicationid',3230),('application_template','application_templateid',3206),('auditlog','auditid',25611),('auditlog_details','auditdetailid',9887),('conditions','conditionid',108),('dchecks','dcheckid',9),('drules','druleid',9),('functions','functionid',30162),('graphs','graphid',51182),('graphs_items','gitemid',115768),('groups','groupid',34),('group_prototype','group_prototypeid',11),('hostmacro','hostmacroid',27),('hosts','hostid',10425),('hosts_groups','hostgroupid',524),('hosts_templates','hosttemplateid',997),('housekeeper','housekeeperid',653212),('httpstep','httpstepid',62),('httpstepitem','httpstepitemid',186),('httptest','httptestid',30),('httptestitem','httptestitemid',90),('images','imageid',192),('interface','interfaceid',392),('items','itemid',151888),('items_applications','itemappid',152844),('item_condition','item_conditionid',453),('item_discovery','itemdiscoveryid',113936),('maintenances','maintenanceid',286),('maintenances_groups','maintenance_groupid',338),('maintenances_hosts','maintenance_hostid',845),('maintenances_windows','maintenance_timeperiodid',366),('mappings','mappingid',171),('media','mediaid',128),('media_type','mediatypeid',34),('opcommand_hst','opcommand_hstid',4),('operations','operationid',59),('opmessage_grp','opmessage_grpid',7),('opmessage_usr','opmessage_usrid',75),('profiles','profileid',14525),('rights','rightid',267),('screens','screenid',161),('screens_items','screenitemid',3444),('screen_user','screenuserid',364),('screen_usrgrp','screenusrgrpid',291),('slides','slideid',3),('slideshows','slideshowid',1),('slideshow_usrgrp','slideshowusrgrpid',1),('sysmaps','sysmapid',4),('sysmaps_elements','selementid',67),('sysmaps_links','linkid',342),('timeperiods','timeperiodid',366),('triggers','triggerid',26908),('trigger_depends','triggerdepid',1466),('users','userid',51),('users_groups','id',87),('usrgrp','usrgrpid',24),('valuemaps','valuemapid',18);
/*!40000 ALTER TABLE `ids` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-30  1:00:40
