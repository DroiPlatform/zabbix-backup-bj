-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `screens`
--

DROP TABLE IF EXISTS `screens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `screens` (
  `screenid` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `hsize` int(11) NOT NULL DEFAULT '1',
  `vsize` int(11) NOT NULL DEFAULT '1',
  `templateid` bigint(20) unsigned DEFAULT NULL,
  `userid` bigint(20) unsigned DEFAULT NULL,
  `private` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screenid`),
  KEY `screens_1` (`templateid`),
  KEY `c_screens_3` (`userid`),
  CONSTRAINT `c_screens_1` FOREIGN KEY (`templateid`) REFERENCES `hosts` (`hostid`) ON DELETE CASCADE,
  CONSTRAINT `c_screens_3` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screens`
--

LOCK TABLES `screens` WRITE;
/*!40000 ALTER TABLE `screens` DISABLE KEYS */;
INSERT INTO `screens` VALUES (3,'System performance',2,3,10001,NULL,0),(4,'Zabbix server health',2,3,10047,NULL,0),(5,'System performance',2,2,10076,NULL,0),(6,'System performance',2,2,10077,NULL,0),(7,'System performance',2,2,10075,NULL,0),(9,'System performance',2,3,10074,NULL,0),(10,'System performance',2,3,10078,NULL,0),(15,'MySQL performance',2,1,10073,NULL,0),(16,'Zabbix server',3,30,NULL,1,0),(17,'Zabbix proxy health',2,2,10048,NULL,0),(18,'System performance',1,2,10079,NULL,0),(19,'System performance',2,2,10081,NULL,0),(20,'MongoDB Production',3,10,NULL,1,1),(21,'MongoDB Production ==',9,10,NULL,1,1),(22,'MongoDB Production |||',9,9,NULL,1,1),(23,'voltdb_prd123',3,20,NULL,1,1),(24,'pg95',3,20,NULL,1,1),(32,'F500D防火墙',2,50,NULL,1,1),(33,'datanode01',2,100,NULL,1,1),(34,'datanode02',2,100,NULL,1,1),(35,'datanode03',2,100,NULL,1,1),(36,'datanode04',2,100,NULL,1,1),(38,'datanode05',2,100,NULL,1,1),(40,'datanode06',2,100,NULL,1,1),(41,'datanode07',2,100,NULL,1,1),(42,'datanode08',2,100,NULL,1,1),(43,'datanode09',2,100,NULL,1,1),(44,'KVM host',2,2,10232,NULL,1),(45,'F5',2,7,NULL,1,1),(49,'网络设备基本信息',3,50,NULL,1,1),(50,'MGMT-SW1',3,100,NULL,1,1),(51,'Core SW-1',3,10,NULL,1,1),(52,'EDGE-SW1',3,10,NULL,1,1),(53,'EDGE-SW2',3,30,NULL,1,1),(54,'EDGE-SW3',3,30,NULL,1,1),(55,'EDGE-SW4',3,50,NULL,1,1),(56,'EDGE-SW5',3,100,NULL,1,1),(57,'MGMT-SW2',3,100,NULL,1,1),(58,'MGMT-SW3',3,100,NULL,1,1),(59,'MGMT-SW4',3,100,NULL,1,1),(60,'MGMT-SW5',3,25,NULL,1,1),(61,'datanode组',6,100,NULL,1,1),(64,'Kafka-screen',2,2,10268,NULL,1),(67,'Accelerator_3',3,100,NULL,1,1),(68,'Linux-kvm',3,20,NULL,1,1),(69,'Beijing Kafka performance',4,12,NULL,18,1),(70,'Beijing Zookeeper Info',3,5,NULL,18,1),(71,'Beijing Kafka server status',3,7,NULL,18,1),(74,'CPU 使用率',3,100,NULL,1,1),(75,'磁盘容量',3,100,NULL,1,1),(76,'Accelerator_1',3,100,NULL,1,1),(77,'Accelerator 主机组流量',3,100,NULL,1,1),(78,'Cephadapter',3,100,NULL,1,1),(79,'masongyu 组网卡流量',3,100,NULL,1,1),(81,'K8S主机组流量',3,100,NULL,1,1),(82,'Linux-server组主机流量',3,100,NULL,1,1),(83,'Log主机组流量',3,100,NULL,1,1),(84,'MongoDB主机组流量',3,100,NULL,1,1),(85,'PGXL主机流量',3,30,NULL,1,1),(86,'Virtual machines主机组流量',3,100,NULL,1,1),(87,'VoltDB主机组流量',3,100,NULL,1,1),(88,'Webcli',3,100,NULL,1,1),(89,'Accelerator_2',3,100,NULL,1,1),(90,'K8S_main',3,100,NULL,1,1),(92,'Proxy-Server',3,100,NULL,1,1),(93,'K8S-jump',3,100,NULL,1,1),(94,'Proxy-server',3,100,NULL,1,1),(95,'Push-data-collect',3,100,NULL,1,1),(96,'Push-server',3,100,NULL,1,1),(97,'Redis-master',3,100,NULL,1,1),(98,'Redis-slave',3,100,NULL,1,1),(99,'Docker_worker_standby_5',3,15,NULL,1,1),(101,'Doghouse',3,100,NULL,1,1),(103,'Standby-1',3,20,NULL,1,1),(104,'Standby-2',3,20,NULL,1,1),(105,'Kafka_1',3,100,NULL,1,1),(106,'Kafka_2',3,100,NULL,1,1),(107,'Kafka_3',3,100,NULL,1,1),(108,'Kafka_4',3,100,NULL,1,1),(109,'Kafka_5',3,100,NULL,1,1),(110,'Kafka_6',3,100,NULL,1,1),(111,'Storm',3,100,NULL,1,1),(112,'Mongo_balance_1',3,25,NULL,1,1),(113,'Mongo_balance_2',3,100,NULL,1,1),(114,'Mongo_conf_1',3,100,NULL,1,1),(115,'Mongo_conf_2',3,100,NULL,1,1),(116,'Mongo_conf_3',3,100,NULL,1,1),(117,'Mongo_datanode_1',3,15,NULL,1,1),(118,'Mongo_datanode_2',3,15,NULL,1,1),(119,'Mongo_datanode_3',3,15,NULL,1,1),(120,'Mongo_datanode_4',3,15,NULL,1,1),(121,'Datanode_1',3,100,NULL,1,1),(122,'Datanode_2',3,100,NULL,1,1),(123,'Datanode_3',3,100,NULL,1,1),(124,'Datanode_4',3,100,NULL,1,1),(125,'Datanode_5',3,100,NULL,1,1),(126,'Etl-dashboard',3,100,NULL,1,1),(127,'Gtm_1',3,100,NULL,1,1),(128,'Gtm_2',3,100,NULL,1,1),(129,'Opdatanode_1',3,100,NULL,1,1),(130,'Opdatanode_2',3,100,NULL,1,1),(131,'Opgtm',3,100,NULL,1,1),(132,'Dns_Server',3,100,NULL,1,1),(133,'Gogs',3,100,NULL,1,1),(134,'BaaS-Web',3,100,NULL,1,1),(135,'Fu-combiner',3,100,NULL,1,1),(136,'Kubedns',3,100,NULL,1,1),(137,'Volt_1',3,100,NULL,1,1),(138,'Volt_2',3,100,NULL,1,1),(139,'Volt_3',3,100,NULL,1,1),(140,'Volt_4',3,100,NULL,1,1),(141,'Volt_5',3,100,NULL,1,1),(142,'Volt_6',3,100,NULL,1,1),(144,'外网网络',3,10,NULL,1,1),(145,'Network Traffic',3,30,NULL,32,1),(146,'內存',3,1,NULL,1,1),(147,'Memory 使用率',3,100,NULL,1,1),(148,'e2e-monitoring',2,14,NULL,1,1),(150,'k8s_worker_4',3,100,NULL,1,1),(151,'k8s_worker_5',3,100,NULL,1,1),(152,'Core switch interfaces',3,20,NULL,1,1),(153,'TMP mongo',3,5,NULL,32,1),(154,'Virtual Machine Network',3,16,NULL,32,1),(155,'CPU usage',3,10,NULL,1,1),(156,'公網進出流量',2,7,NULL,1,1),(157,'外部流量-by service',4,11,NULL,1,1);
/*!40000 ALTER TABLE `screens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-20  1:01:14
