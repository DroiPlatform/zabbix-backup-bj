-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `httpstep`
--

DROP TABLE IF EXISTS `httpstep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `httpstep` (
  `httpstepid` bigint(20) unsigned NOT NULL,
  `httptestid` bigint(20) unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `no` int(11) NOT NULL DEFAULT '0',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `timeout` int(11) NOT NULL DEFAULT '15',
  `posts` text NOT NULL,
  `required` varchar(255) NOT NULL DEFAULT '',
  `status_codes` varchar(255) NOT NULL DEFAULT '',
  `variables` text NOT NULL,
  `follow_redirects` int(11) NOT NULL DEFAULT '1',
  `retrieve_mode` int(11) NOT NULL DEFAULT '0',
  `headers` text NOT NULL,
  PRIMARY KEY (`httpstepid`),
  KEY `httpstep_1` (`httptestid`),
  CONSTRAINT `c_httpstep_1` FOREIGN KEY (`httptestid`) REFERENCES `httptest` (`httptestid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httpstep`
--

LOCK TABLES `httpstep` WRITE;
/*!40000 ALTER TABLE `httpstep` DISABLE KEYS */;
INSERT INTO `httpstep` VALUES (3,3,'login',1,'https://175.25.22.132',15,'','','200','',1,0,''),(4,4,'www.droibaas.com',1,'www.droibaas.com',20,'','','200','',1,0,''),(5,5,'http://www.droibaas.com/Index/about.html',1,'http://www.droibaas.com/Index/about.html',15,'','','200','',1,0,''),(6,6,'bbs.droibaas.com',1,'bbs.droibaas.com',15,'','','200','',1,0,''),(7,7,'job.droibaas.com',1,'job.droibaas.com',15,'','','200','',1,0,''),(9,8,'BaaSWeb',1,'http://www.droibaas.com/Index/price.html',15,'','','200','',1,0,''),(10,9,'20550',1,'http://10.10.60.8:20550/version/cluster',15,'','','200','',1,0,''),(13,12,'PushService',1,'http://push_service.droi.cn:2500/device/message/status',15,'','','200','',1,0,''),(16,13,'Push',1,'http://push_service.droi.cn:2500/device/message/status',15,'','2010002','200','',1,0,''),(20,14,'File Abyss',3,'http://10.10.50.109:8888/v2/health',15,'','\"Code\":0','200','',0,0,''),(21,14,'File Majesty',4,'http://10.10.50.61:31110/v1/health',15,'','\"Code\":0','200','',0,0,''),(22,14,'CDN Publisher',5,'http://10.10.50.61:31119/status',15,'','\"Code\":0','200','',0,0,''),(29,14,'RDB API',2,'http://10.10.50.61:30109/v1/upload_file/497umbzhcHN44alFPsXyQ4cZdUyo31PMlQAwT0AO?limit=1',15,'','\"code\":0','200','',0,0,''),(32,14,'Acc',1,'http://accelentry.droibaas.com/welcome',15,'','','200','',0,1,''),(33,16,'Account',1,'https://account.droi.com/oauth/checkexist?uid=18721991496&sign=be9f54ef37b2d0608bd21ecf05345316&usertype=mobile',15,'','\"result\":0','200','',1,0,''),(34,17,'Update',1,'http://10.10.40.215:12000/droiupdate/apps/2b8umbzhdS9wEkXXak0slXqFpMxSd3_8lQCAiLwR',15,'','\"Code\":0','200','',1,0,'X-Droi-AppID: 2b8umbzhdS9wEkXXak0slXqFpMxSd3_8lQCAiLwR'),(35,18,'Feedback',1,'http://10.10.40.215:12000/droifeedback/vc8umbzh30JpfQq8iraucId2L9WNOVqRlQA9KSgR',15,'','\"Code\":0','200','',1,0,'X-Droi-AppID: vc8umbzh30JpfQq8iraucId2L9WNOVqRlQA9KSgR'),(36,19,'Analytics',1,'http://10.10.60.8:20550/version/cluster',15,'','','200','',1,1,''),(37,20,'Web',1,'http://www.droibaas.com',15,'','','200','',1,1,''),(40,21,'GoBuster',1,'http://10.10.50.61:30110/health/v2',15,'','\"Code\":0','200','',1,0,''),(43,22,'GoBuster',1,'http://10.10.50.61:30110/health/v2',15,'','\"Code\":0','200','',1,0,''),(44,22,'Baas Jenkins',2,'http://10.10.50.61:30180/job/cloudcode/',15,'','','200','',0,1,''),(45,22,'WebCLI Application',3,'http://10.10.40.215:12000/apps',15,'','\"Code\":0','200','',1,0,'x-droi-developerid:777'),(46,22,'WebCLI Job',4,'http://10.10.40.215:12000/apps/ua8umbzh4QXUi_8GPdcTQzDzPmmi8nxplQAAzAcb/job_cloudcode',15,'','\"Code\":0','200','',1,0,'X-Droi-DeveloperId:777\r\nX-Droi-AppID:ua8umbzh4QXUi_8GPdcTQzDzPmmi8nxplQAAzAcb'),(48,21,'WebCLI Object',2,'http://10.10.40.215:12000/schemas',15,'','\"Code\":0','200','',1,0,'X-Droi-DeveloperId:777\r\nX-Droi-AppID:ua8umbzh4QXUi_8GPdcTQzDzPmmi8nxplQAAzAcb'),(49,23,'WebCLI Log',1,'http://10.10.40.215:12000/joblogs',15,'','\"Code\":0','200','',1,0,'X-Droi-DeveloperId:777\r\nX-Droi-AppID:ua8umbzh4QXUi_8GPdcTQzDzPmmi8nxplQAAzAcb\r\nType:0\r\nlimit:1'),(50,24,'Gosun Download',1,'http://newmarket1.oo523.com/droi/497umbzhcHN44alFPsXyQ4cZdUyo31PMlQAwT0AO/890057812137349120/droi.jpg',15,'','','200','',1,1,''),(51,24,'Gosun Upload API',3,'http://gsvc.v.c4hcdn.com:8080/portal/mds/deliver_v2.jsp',15,'','','200','',1,1,''),(55,25,'Account',1,'https://account.droi.com/oauth/checkexist?uid=18721991496&sign=be9f54ef37b2d0608bd21ecf05345316&usertype=mobile',20,'','','200','',1,0,''),(56,26,'海外帐号服务',1,'http://service-account.dd351.com/oauth/checkexist?uid=18721991496&sign=be9f54ef37b2d0608bd21ecf05345316&usertype=mobile',15,'','','200','',1,0,''),(58,28,'BaaS帐号服务',1,'https://account.droi.com/oauth/checkexist?uid=18721991496&sign=be9f54ef37b2d0608bd21ecf05345316&usertype=mobile',15,'','','200','',1,0,''),(59,20,'Web-HTTPS',2,'https://www.droibaas.com',15,'','','200','',1,1,''),(62,24,'Qiniu Downloads',2,'http://497umbzh.droibaascdn.com/droi/497umbzhcHN44alFPsXyQ4cZdUyo31PMlQAwT0AO/890057812137349120/droi.jpg',15,'','','200','',1,1,''),(63,31,'http://newsstream.droibaas.com/staticfiles/fxajx.js',1,'http://newsstream.droibaas.com/staticfiles/fxajx.js',15,'','','200','',1,0,''),(64,32,'xiudian',1,'https://www.xiudian.com',15,'','','200','',1,0,''),(66,34,'curl_port_18083',1,'http://175.25.22.141:18083/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(67,34,'curl_port_18087',2,'http://175.25.22.141:18087/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(68,35,'curl_port_18080',1,'http://175.25.22.142:18080/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(69,35,'curl_port_18083',2,'http://175.25.22.142:18083/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(70,35,'curl_port_18085',3,'http://175.25.22.142:18085/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(71,35,'curl_port_18087',4,'http://175.25.22.142:18087/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(72,34,'curl_port_18085',3,'http://175.25.22.141:18085/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(73,34,'curl_port_18080',4,'http://175.25.22.141:18080/ip_list?appid=za8umbzhV32pFTo4vQpzdR-JbVRmRRzPlQDdGTYA',15,'','Expire','200','',1,0,''),(75,37,'jm.droi.com',1,'http://10.10.80.251/t/7a58c831be8d38f9dd25e04bb79655aa640f97c2725434a154f8bf460d72d7713ea68c4fb4a6790519087449f10455c7',20,'','','200','',1,0,''),(76,38,'https://www.droibaas.com/Index/price.html',1,'https://www.droibaas.com/Index/price.html',15,'','','200','',1,0,'');
/*!40000 ALTER TABLE `httpstep` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-31  1:00:35
