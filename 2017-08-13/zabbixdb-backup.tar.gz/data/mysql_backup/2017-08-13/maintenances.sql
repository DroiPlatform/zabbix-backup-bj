-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `maintenances`
--

DROP TABLE IF EXISTS `maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenances` (
  `maintenanceid` bigint(20) unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `maintenance_type` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `active_since` int(11) NOT NULL DEFAULT '0',
  `active_till` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`maintenanceid`),
  UNIQUE KEY `maintenances_2` (`name`),
  KEY `maintenances_1` (`active_since`,`active_till`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenances`
--

LOCK TABLES `maintenances` WRITE;
/*!40000 ALTER TABLE `maintenances` DISABLE KEYS */;
INSERT INTO `maintenances` VALUES (148,'TP-SH network tuning',0,'',1488816000,1489161600),(149,'Upload File Partition Table 優化',0,'worktile - https://droi.worktile.com/tasks/projects/57e2ccd49b824009104c67b1/58a7c28bc286a7659881012e',1489014000,1489019400),(150,'EDGE-5',0,'',1489406400,1489410000),(151,'linux lvm add vm',0,'',1488988800,1489075200),(152,'kafka transfer vlan 40 to 42',0,'',1489420800,1489507200),(153,'netkafavlan',0,'',1489474800,1489492800),(154,'mevoco',0,'',1489640400,1489766400),(156,'gobuster rolling update',0,'',1489593600,1489680000),(157,'add abyss host',0,'',1489593600,1489680000),(158,'accelerator nginx status',0,'',1489680000,1489766400),(159,'release SDK e2e test',0,'',1489988640,1490076000),(161,'accelerator RFC 20170323',0,'',1490198400,1490284800),(162,'Adjust DroiBaaS System Status',0,'',1490682060,1490782920),(164,'上版',0,'baasjenkins/ gobuster/lua app',1490198400,1490284800),(165,'vm 調整',0,'',1490371200,1490457600),(166,'Accelerator update',0,'',1490544000,1490976000),(167,'BJ CoreOS and K8S upgrade',0,'',1490544000,1490889540),(168,'accelerator-3 reboot test',0,'',1490672520,1490716800),(171,'accelerator RFC 0406',0,'',1491444000,1491580800),(172,'k8s tuning',0,'',1491408000,1491494400),(173,'RFC #23199',0,'',1491408000,1491494400),(176,'Live Coding Feature',0,'',1491926400,1492099200),(177,'accelerator-RFC-0413',0,'',1492012800,1492099200),(178,'runtime general zone 更新',0,'',1492012800,1492099200),(181,'bugfix @webcli',0,'',1492358400,1492444800),(183,'WebCLI e2e test refactoring',0,'',1492502400,1492531200),(184,'test reboot msg',0,'',1492444800,1492531200),(185,'accelerator-k8s-worker-domain-test',0,'',1492536900,1492617600),(187,'PG rfc',0,'',1492617600,1492704000),(188,'10.10.60.1020170425',0,'',1493049600,1493136000),(189,'update',0,'',1493222400,1493308800),(190,'acc-3 CORS test',0,'',1493740800,1493827200),(191,'accelerator-RFC 0504',0,'',1493827200,1493913600),(192,'RFC',0,'',1493827200,1493913600),(193,'50.81 fix',0,'',1493827200,1493913600),(196,'tuning template',0,'',1494172800,1494259200),(197,'K8S Reguly Reboot',0,'',1494345600,1494432000),(198,'#24977 Deployment V3 for runtime service (LuaApp and jsLoader)',0,'',1494459000,1494496800),(199,'k8s deploy',0,'',1494432000,1494518400),(201,'K8S issue tracking',0,'',1494518400,1494604800),(205,'k8s',0,'',1494950400,1495036800),(206,'push-service',0,'push-service 推送',1495029600,1495033200),(207,'service update',0,'',1495036800,1495123200),(209,'Web 版本更新20170524',0,'',1495581900,1495587600),(212,'20170525 FileService release',0,'',1495641600,1495728000),(213,'kafka-7 機器設定',0,'',1495728000,1496160000),(214,'webcli 上版',0,'',1496296800,1496376000),(215,'worker-5重開',0,'',1496246400,1496332800),(216,'nfs add zabbix monitoring',0,'',1496246400,1496332800),(217,'nfs server monitoring item updating',0,'',1496332800,1496419200),(218,'smartctl zabbix tuning',0,'',1496332800,1497176580),(219,'mongo datanode2 service down',0,'',1496592000,1496678400),(220,'kafka reboot',0,'',1496592000,1497096060),(221,'accelerator RFC 0608',0,'',1496887560,1496937600),(222,'20170608 DroiFile Regular Release',0,'',1496851200,1496937600),(223,'20170615 DroiFile Regular Release',0,'',1497492000,1497607200),(224,'20170615 mongo update',0,'',1497456000,1497542400),(225,'droipush',0,'',1497934800,1497938400),(226,'linux-kvm02 shutdown unused vm',0,'ubuntu vm',1497888000,1497974400),(227,'Abyss hotfix for object size',0,'',1497888000,1497974400),(228,'droipush222',0,'',1497942000,1498032000),(229,'c',0,'',1498060800,1498147200),(231,'taipei firewall upgrade',0,'',1498579200,1499443200),(232,'Abyss API Updated',0,'',1498701600,1498752000),(233,'kaka-mongo',0,'',1498665600,1498924800),(234,'e2e tuning',0,'',1498665600,1498752000),(235,'mongo',0,'',1499011200,1499184000),(236,'log service zabbix template tuning',0,'https://droi.worktile.com/tasks/projects/578ddeedb17f2d0c03716009/5959ee11f51e8773f680692b',1499097600,1499443200),(237,'zabbix tuning',0,'',1499270400,1499356800),(238,'20170713 DroiBaaS Regular Release',0,'',1499911200,1499961600),(239,'60.6',0,'',1500522900,1500524400),(240,'Increase abyss concurrent',0,'https://droi.worktile.com/tasks/projects/578ddeedb17f2d0c03716009/596ed3655bfbe622e56c1fa9',1500393600,1500480000),(241,'20170720 DroiBaaS Regular Release',0,'',1500516000,1500566400),(242,'F5 template adding',0,'',1500480000,1500566400),(243,'nfs rsync',0,'',1500825600,1501084800),(245,'nfs ha',0,'',1500912000,1500998400),(246,'40.221',0,'',1501041180,1501042800),(247,'20170727 DroiBaaS Regular Release',0,'',1501084800,1501171200),(248,'mongo zabbix template tuning',0,'',1501084800,1501171200),(249,'runtime update',0,'',1501171200,1501257600),(251,'20170801 FileService patch for 微創',0,'',1501516800,1501689600),(252,'20170803 DroiBaaS Regular Release',0,'',1501689600,1501776000),(253,'accelerator RFC0803',0,'',1501726080,1501819200),(255,'gobuster 上版',0,'',1502121600,1502208000),(257,'Accelerator RFC 0810',0,'',1502329800,1502380800),(258,'20170810 DroiBaaS Regular Release',0,'',1502294400,1502380800);
/*!40000 ALTER TABLE `maintenances` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-13  1:00:49
