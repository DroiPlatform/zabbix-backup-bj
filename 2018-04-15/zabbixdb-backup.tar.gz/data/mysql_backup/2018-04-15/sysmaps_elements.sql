-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sysmaps_elements`
--

DROP TABLE IF EXISTS `sysmaps_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sysmaps_elements` (
  `selementid` bigint(20) unsigned NOT NULL,
  `sysmapid` bigint(20) unsigned NOT NULL,
  `elementid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `elementtype` int(11) NOT NULL DEFAULT '0',
  `iconid_off` bigint(20) unsigned DEFAULT NULL,
  `iconid_on` bigint(20) unsigned DEFAULT NULL,
  `label` varchar(2048) NOT NULL DEFAULT '',
  `label_location` int(11) NOT NULL DEFAULT '-1',
  `x` int(11) NOT NULL DEFAULT '0',
  `y` int(11) NOT NULL DEFAULT '0',
  `iconid_disabled` bigint(20) unsigned DEFAULT NULL,
  `iconid_maintenance` bigint(20) unsigned DEFAULT NULL,
  `elementsubtype` int(11) NOT NULL DEFAULT '0',
  `areatype` int(11) NOT NULL DEFAULT '0',
  `width` int(11) NOT NULL DEFAULT '200',
  `height` int(11) NOT NULL DEFAULT '200',
  `viewtype` int(11) NOT NULL DEFAULT '0',
  `use_iconmap` int(11) NOT NULL DEFAULT '1',
  `application` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`selementid`),
  KEY `sysmaps_elements_1` (`sysmapid`),
  KEY `sysmaps_elements_2` (`iconid_off`),
  KEY `sysmaps_elements_3` (`iconid_on`),
  KEY `sysmaps_elements_4` (`iconid_disabled`),
  KEY `sysmaps_elements_5` (`iconid_maintenance`),
  CONSTRAINT `c_sysmaps_elements_1` FOREIGN KEY (`sysmapid`) REFERENCES `sysmaps` (`sysmapid`) ON DELETE CASCADE,
  CONSTRAINT `c_sysmaps_elements_2` FOREIGN KEY (`iconid_off`) REFERENCES `images` (`imageid`),
  CONSTRAINT `c_sysmaps_elements_3` FOREIGN KEY (`iconid_on`) REFERENCES `images` (`imageid`),
  CONSTRAINT `c_sysmaps_elements_4` FOREIGN KEY (`iconid_disabled`) REFERENCES `images` (`imageid`),
  CONSTRAINT `c_sysmaps_elements_5` FOREIGN KEY (`iconid_maintenance`) REFERENCES `images` (`imageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmaps_elements`
--

LOCK TABLES `sysmaps_elements` WRITE;
/*!40000 ALTER TABLE `sysmaps_elements` DISABLE KEYS */;
INSERT INTO `sysmaps_elements` VALUES (42,4,10252,0,191,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,1200,155,NULL,NULL,0,0,200,200,0,0,'ICMP'),(44,4,10246,0,188,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,505,260,NULL,NULL,0,0,200,200,0,0,'ICMP'),(45,4,10247,0,190,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,900,160,NULL,NULL,0,0,200,200,0,0,'ICMP'),(46,4,0,4,5,NULL,'Internet',-1,26,549,NULL,NULL,0,0,200,200,0,0,''),(47,4,10259,0,189,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,200,550,NULL,NULL,0,0,200,200,0,0,'ICMP'),(48,4,10253,0,191,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,1200,555,NULL,NULL,0,0,200,200,0,0,'ICMP'),(49,4,10248,0,190,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,900,360,NULL,NULL,0,0,200,200,0,0,'ICMP'),(51,4,10246,0,188,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,505,860,NULL,NULL,0,0,200,200,0,0,'ICMP'),(52,4,10249,0,190,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,900,560,NULL,NULL,0,0,200,200,0,0,'ICMP'),(53,4,10254,0,191,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,1200,755,NULL,NULL,0,0,200,200,0,0,'ICMP'),(54,4,10250,0,190,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,900,760,NULL,NULL,0,0,200,200,0,0,'ICMP'),(64,4,10261,0,191,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,1200,955,NULL,NULL,0,0,200,200,0,0,'ICMP'),(65,4,10251,0,190,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,900,960,NULL,NULL,0,0,200,200,0,0,'ICMP'),(66,4,10259,0,192,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,1500,560,NULL,NULL,0,0,200,200,0,0,'ICMP'),(67,4,10261,0,191,NULL,'{HOST.NAME}\r\n{HOST.CONN}',-1,1500,755,NULL,NULL,0,0,200,200,0,0,'ICMP');
/*!40000 ALTER TABLE `sysmaps_elements` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-15  1:01:33
