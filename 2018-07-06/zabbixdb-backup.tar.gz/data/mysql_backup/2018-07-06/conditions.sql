-- MySQL dump 10.13  Distrib 5.6.30, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	5.6.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conditions`
--

DROP TABLE IF EXISTS `conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conditions` (
  `conditionid` bigint(20) unsigned NOT NULL,
  `actionid` bigint(20) unsigned NOT NULL,
  `conditiontype` int(11) NOT NULL DEFAULT '0',
  `operator` int(11) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`conditionid`),
  KEY `conditions_1` (`actionid`),
  CONSTRAINT `c_conditions_1` FOREIGN KEY (`actionid`) REFERENCES `actions` (`actionid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conditions`
--

LOCK TABLES `conditions` WRITE;
/*!40000 ALTER TABLE `conditions` DISABLE KEYS */;
INSERT INTO `conditions` VALUES (2,2,10,0,'0'),(3,2,8,0,'9'),(4,2,12,2,'Linux'),(5,3,16,7,''),(6,3,5,0,'1'),(7,4,23,0,'0'),(8,5,23,0,'2'),(9,6,23,0,'4'),(21,9,16,7,''),(22,9,5,0,'1'),(23,9,0,0,'16'),(27,11,16,7,''),(28,11,5,0,'1'),(29,11,0,0,'14'),(30,12,16,7,''),(31,12,5,0,'1'),(32,12,0,0,'13'),(33,13,16,7,''),(34,13,5,0,'1'),(35,13,0,0,'12'),(36,14,16,7,''),(37,14,5,0,'1'),(38,14,0,0,'22'),(39,15,16,7,''),(40,15,5,0,'1'),(41,15,0,0,'22'),(42,16,16,7,''),(43,16,5,0,'1'),(44,16,0,0,'15'),(45,17,16,7,''),(46,17,5,0,'1'),(47,17,1,0,'10325'),(48,18,16,7,''),(49,18,5,0,'1'),(50,18,0,0,'23'),(57,21,16,7,''),(58,21,5,0,'1'),(59,21,0,0,'8'),(67,17,0,0,'24'),(68,18,1,0,'10325'),(69,14,0,0,'21'),(71,23,16,7,''),(72,23,5,0,'1'),(73,23,2,0,'25354'),(81,25,16,7,''),(82,25,5,0,'1'),(84,26,16,7,''),(85,26,5,0,'1'),(86,26,0,0,'30'),(87,26,0,0,'22'),(88,27,16,7,''),(89,27,5,0,'1'),(90,27,1,0,'10325'),(91,28,16,7,''),(92,28,3,2,'System Status'),(101,28,1,0,'10325'),(102,23,2,0,'25353'),(103,23,0,0,'28'),(104,31,16,7,''),(105,31,5,0,'1'),(106,31,0,0,'33'),(109,25,1,0,'10426');
/*!40000 ALTER TABLE `conditions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-06  1:00:07
